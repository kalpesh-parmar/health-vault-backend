"""High-level service abstractions (LLM providers, factories, etc.)."""
